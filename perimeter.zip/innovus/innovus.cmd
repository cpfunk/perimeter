#######################################################
#                                                     
#  Innovus Command Logging File                     
#  Created on Tue May  5 15:44:22 2026                
#                                                     
#######################################################

#@(#)CDS: Innovus v25.10-p002_1 (64bit) 04/23/2025 12:43 (Linux 4.18.0-305.el8.x86_64)
#@(#)CDS: NanoRoute 25.10-p002_1 NR250317-0405/25_10-UB (database version 18.20.663) {superthreading v2.20}
#@(#)CDS: AAE 25.10-b008 (64bit) 04/23/2025 (Linux 4.18.0-305.el8.x86_64)
#@(#)CDS: CTE 25.10-b014_1 () Mar 28 2025 03:11:49 ( )
#@(#)CDS: SYNTECH 25.10-b006_1 () Mar 13 2025 03:32:26 ( )
#@(#)CDS: CPE v25.10-b011
#@(#)CDS: IQuantus/TQuantus 24.1.0-s201 (64bit) Thu Mar 20 10:21:58 PDT 2025 (Linux 4.18.0-305.el8.x86_64)

set_global _enable_mmmc_by_default_flow      $CTE::mmmc_default
suppressMessage ENCEXT-2799
getVersion
win
set init_gnd_net GND
set init_lef_file {../lef/gsclib045_tech.lef ../lef/gsclib045_macro.lef}
set init_verilog ../synthesis_outputs/perimeter_synth.v
set init_pwr_net VDD
init_design
zoomBox -6.25150 -2.79950 58.04500 54.75950
zoomBox -5.64000 -2.47500 49.01200 46.45000
zoomBox -3.63500 -1.33500 20.61500 20.37400
zoomBox -1.83200 -0.77950 7.31400 7.40800
zoomBox -1.05450 -0.52500 3.72050 3.74950
zoomBox -0.67600 -0.38550 2.25700 2.24000
zoomBox -0.59100 -0.34750 1.90250 1.88450
zoomBox -0.78300 -0.70750 3.99350 3.56850
fit
getIoFlowFlag
setIoFlowFlag 0
floorPlan -site CoreSite -r 1 0.5 10 10 10 10
uiSetTool select
getIoFlowFlag
fit
setIoFlowFlag 0
floorPlan -site CoreSite -r 0.967924528302 0.499615 10.0 10.07 10.0 10.07
uiSetTool select
getIoFlowFlag
fit
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal11 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {GND VDD} -type core_rings -follow core -layer {top Metal1 bottom Metal1 left Metal2 right Metal2} -width {top 1.8 bottom 1.8 left 1.8 right 1.8} -spacing {top 1.8 bottom 1.8 left 1.8 right 1.8} -offset {top 3 bottom 3 left 3 right 3} -center 0 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal11 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {GND VDD} -type core_rings -follow core -layer {top Metal1 bottom Metal1 left Metal2 right Metal2} -width {top 1.8 bottom 1.8 left 1.8 right 1.8} -spacing {top 1.8 bottom 1.8 left 1.8 right 1.8} -offset {top 3 bottom 3 left 3 right 3} -center 0 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
setPlaceMode -fp false
place_design
setDrawView place
zoomBox -18.36050 -16.38600 112.10450 100.40800
zoomBox 9.96900 14.78400 90.09150 86.51050
zoomBox 16.73250 22.23150 84.83650 83.19900
zoomBox 22.48100 28.56150 80.36950 80.38400
zoomBox 40.38850 48.60050 66.07500 71.59550
zoomBox 37.89600 45.72700 68.11550 72.78000
zoomBox 34.93600 42.37400 70.48850 74.20100
zoomBox 31.45400 38.42950 73.28050 75.87300
zoomBox 2.26300 26.33550 126.80850 90.36800
zoomBox 15.66550 37.93150 105.65050 84.19550
zoomBox 23.62350 45.33400 88.63800 78.76000
zoomBox 26.73150 48.25450 81.99400 76.66650
zoomBox 33.75300 54.67800 67.69150 72.12700
zoomBox 35.42950 56.21150 64.27800 71.04350
zoomBox 8.22150 37.97650 98.21600 84.24550
zoomBox -10.44400 27.23050 114.11650 91.27100
fit
zoomBox -5.71150 19.74100 95.08500 71.56350
zoomBox 0.92550 23.74150 86.60250 67.79050
zoomBox 19.33050 33.99250 64.05600 56.98750
zoomBox 30.64050 39.91700 50.48650 50.12050
fit
zoomBox -15.70500 16.34750 102.87900 77.31500
zoomBox -9.17000 22.51900 91.62650 74.34150
zoomBox 6.21650 37.27850 68.11850 69.10400
zoomBox 15.09050 45.74300 53.10700 65.28850
zoomBox 21.50100 51.59950 41.34550 61.80200
zoomBox 22.54100 52.55850 39.40900 61.23100
zoomBox 21.59000 51.77450 41.43550 61.97750
zoomBox 20.47400 50.85850 43.82150 62.86200
zoomBox 19.16100 49.78300 46.62850 63.90500
zoomBox 17.60400 48.52650 49.91950 65.14100
zoomBox 15.74850 47.04150 53.76700 66.58800
zoomBox 10.68150 43.01600 63.30300 70.07050
zoomBox 6.86150 40.41900 68.77000 72.24800
zoomBox 1.88850 37.14750 74.72200 74.59350
zoomBox -3.93900 33.36050 81.74750 77.41450
zoomBox -10.68550 28.97750 90.12200 80.80600
selectWire 89.2000 5.2700 91.0000 84.9800 2 GND
fit
::uiSetTool getLocation Rda_PE::Attr:getStartCoord
uiSetTool select
deselectAll
::uiSetTool getLocation Rda_PE::Attr:getStartCoord
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 5.0 -pin {A_hundreds A_ones A_tens A_thousands B_hundreds B_ones B_tens B_thousands C_hundreds C_ones C_tens C_thousands clk_1kHz_ext clk_16MHz clk_mux_s D_hundreds D_ones D_tens D_thousands E_hundreds E_ones E_tens E_thousands F_hundreds F_ones F_tens F_thousands G_hundreds G_ones G_tens G_thousands {rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 5.0 -pin {A_hundreds A_ones A_tens A_thousands B_hundreds B_ones B_tens B_thousands C_hundreds C_ones C_tens C_thousands clk_1kHz_ext clk_16MHz clk_mux_s D_hundreds D_ones D_tens D_thousands E_hundreds E_ones E_tens E_thousands F_hundreds F_ones F_tens F_thousands G_hundreds G_ones G_tens G_thousands {rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
zoomBox 22.98650 33.88550 123.78250 85.70800
zoomBox 58.32800 51.46150 110.94600 78.51400
zoomBox 64.10800 54.34700 108.83400 77.34200
zoomBox 51.38050 48.39600 113.28600 80.22350
zoomBox 32.01050 40.60700 117.69300 84.65900
zoomBox 19.60850 35.74250 120.41150 87.56850
zoomBox -11.70400 22.96100 127.81700 94.69300
zoomBox -31.21800 14.92150 132.92500 99.31250
zoomBox -80.44300 -5.30200 146.74450 111.50200
zoomBox -53.61900 -0.50700 139.49050 98.77650
zoomBox -80.91450 -5.73300 146.27350 111.07150
zoomBox -112.01400 -8.52950 155.26600 128.88750
zoomBox -31.56000 -4.71400 132.58400 79.67750
zoomBox -12.38750 -3.50000 127.13550 68.23300
zoomBox 3.90950 -2.43050 122.50450 58.54300
zoomBox 61.77050 1.00400 106.49950 24.00050
zoomBox 78.53300 1.93000 101.88150 13.93400
zoomBox 88.45150 2.99850 98.81150 8.32500
zoomBox 91.45400 3.40900 97.81700 6.68050
zoomBox 89.46950 2.79600 98.27750 7.32450
zoomBox 93.34250 3.58200 97.25100 5.59150
zoomBox 93.80000 3.67550 97.12300 5.38400
zoomBox 95.18650 4.00350 96.66200 4.76200
zoomBox 95.79900 4.14750 96.45450 4.48450
zoomBox 95.70450 4.12400 96.47600 4.52050
zoomBox 93.50800 3.63350 96.84000 5.34650
zoomBox 89.12050 2.59400 97.95600 7.13650
zoomBox 87.89500 2.29950 98.29000 7.64400
zoomBox 70.78300 -1.98200 103.21250 14.69100
zoomBox 55.06150 -5.96450 107.86900 21.18550
zoomBox 17.75550 -15.41500 118.91850 36.59600
zoomBox 3.99300 -18.95750 123.00850 42.23200
zoomBox -189.51400 -71.86000 181.74100 119.01350
zoomBox -240.37400 -89.51000 196.39650 135.04750
zoomBox -205.15450 -76.66700 166.10100 114.20700
zoomBox -127.53900 -48.49800 100.45850 68.72250
zoomBox -109.01000 -41.77350 84.78800 57.86400
zoomBox -93.26050 -35.84800 71.46800 48.84400
zoomBox -41.67750 -16.41850 31.41450 21.16050
zoomBox -13.86700 -5.78250 9.56650 6.26550
zoomBox -48.54250 -22.09750 37.45800 22.11800
zoomBox -107.89800 -50.33600 85.92550 49.31450
zoomBox -304.90850 -132.80750 209.01000 131.41400
zoomBox -112.67400 -58.50800 155.59600 79.41800
zoomBox 18.93800 -9.86700 120.11750 42.15250
zoomBox 76.70000 11.69300 104.27200 25.86850
zoomBox 90.62250 17.13350 99.46150 21.67800
zoomBox 94.39800 18.68350 97.73200 20.39750
zoomBox 95.50300 19.22650 96.98300 19.98750
zoomBox 92.19500 17.88600 98.59200 21.17500
zoomBox 75.52600 12.38850 103.15150 26.59150
zoomBox 21.64850 -6.77850 123.03150 45.34550
zoomBox -26.52300 -23.56750 138.56350 61.30850
zoomBox -252.76300 -118.74750 184.95900 106.29900
uiSetTool select
zoomBox -32.93200 9.91150 132.15600 94.78850
zoomBox 49.38450 58.32000 111.64800 90.33150
zoomBox 79.85450 76.94000 103.33800 89.01350
zoomBox 89.66700 82.75200 100.08750 88.10950
zoomBox 92.99750 84.69400 98.43700 87.49050
zoomBox 94.51350 85.47200 97.35300 86.93200
zoomBox 95.32450 85.88000 96.80750 86.64250
zoomBox 91.31250 83.98000 98.85150 87.85600
zoomBox 81.19400 78.97450 104.71250 91.06600
zoomBox 49.63100 63.35200 122.99650 101.07150
zoomBox -27.08800 25.43850 167.43900 125.45100
zoomBox -104.48200 -12.78100 212.27300 150.07250
fit
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 0.2 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
zoomBox -8.69150 9.13600 130.81850 80.86250
zoomBox 41.51200 25.56800 114.33900 63.01050
zoomBox 62.56700 32.32650 107.29250 55.32150
zoomBox 62.56650 32.32600 107.29300 55.32150
zoomBox 57.33100 30.66000 109.95100 57.71350
zoomBox 42.75050 26.23150 115.58100 63.67600
zoomBox 33.58400 23.42600 119.26750 67.47850
zoomBox 22.80950 20.12550 123.61350 71.95200
zoomBox -6.23350 10.53350 133.28850 82.26600
zoomBox -24.62250 4.43350 139.52150 88.82500
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 2 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
zoomBox -77.41850 -13.88650 149.77100 102.91850
zoomBox -108.51850 -25.67600 158.76350 111.74200
zoomBox -77.63600 -13.88700 149.55400 102.91850
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 1 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
zoomBox -51.48800 -6.16150 141.62350 93.12300
zoomBox -29.34950 0.26550 134.79550 84.65750
zoomBox -10.54650 5.71350 128.97700 77.44700
zoomBox 5.43550 10.34450 124.03100 71.31800
zoomBox -28.80050 -0.70850 135.34550 83.68400
zoomBox -50.39950 -7.78050 142.71350 91.50500
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 1.2 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 1.4 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 1.33 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 1.33 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]} {rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
zoomBox -104.68650 -29.40850 162.59850 108.01100
zoomBox -139.82850 -42.45550 174.62450 119.21450
zoomBox -25.38600 7.82150 138.76000 92.21400
zoomBox -6.68650 16.36450 132.83750 88.09800
zoomBox 22.41400 32.02000 123.22050 83.84800
zoomBox -100.15350 -30.32850 167.13350 107.09200
zoomBox -79.85400 -16.12850 147.34000 100.67900
zoomBox -62.62000 -4.05850 130.49500 95.22800
zoomBox -86.82200 -17.05100 140.37300 99.75700
zoomBox -115.36700 -32.33600 151.92100 105.08500
zoomBox -83.59150 -17.53300 143.60350 99.27500
zoomBox -12.21550 14.52400 127.31100 86.25900
zoomBox 4.66100 22.27650 123.25850 83.25100
zoomBox -53.87350 -4.55800 139.24300 94.72900
zoomBox -80.49350 -16.42350 146.70250 100.38500
zoomBox -141.60000 -40.86750 172.85800 120.80500
zoomBox 7.03750 39.14500 125.63700 100.12050
zoomBox 62.77300 69.81200 107.50500 92.81000
zoomBox 81.44450 80.08000 101.29350 90.28500
zoomBox 83.67150 81.25050 100.54350 89.92500
zoomBox 90.64050 84.84500 98.12750 88.69450
zoomBox 93.23300 86.08700 97.14200 88.09650
zoomBox 94.00150 86.42150 96.82550 87.87350
zoomBox 94.30100 86.55200 96.70200 87.78650
zoomBox 91.50300 85.31950 97.87000 88.59300
zoomBox 87.39950 83.51950 99.59950 89.79200
zoomBox 73.12650 77.33400 105.47550 93.96550
zoomBox 52.14400 68.17800 114.11450 100.03900
zoomBox -3.03300 46.27900 136.63300 118.08550
zoomBox -93.40350 27.95850 174.15300 165.51750
zoomBox -166.25900 16.55500 204.06100 206.94800
gui_select -rect {113.20700 58.64200 110.75750 63.54100}
zoomBox -413.46200 -37.26200 295.95650 327.47200
zoomBox -95.57300 -10.06250 171.98500 127.49750
zoomBox 23.71900 -1.71850 124.62950 50.16250
zoomBox 68.54000 1.53100 106.59950 21.09850
zoomBox 85.61750 2.50350 99.97200 9.88350
zoomBox 91.44050 3.00500 97.81050 6.28000
zoomBox 93.21750 3.18350 97.13100 5.19550
zoomBox 85.68200 2.21950 100.04700 9.60500
fit
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Top -layer 1 -spreadType center -spacing 1.33 -pin {G_thousands D_hundreds D_ones D_tens D_thousands E_hundreds E_ones E_tens E_thousands F_hundreds F_ones F_tens F_thousands G_hundreds G_ones G_tens C_thousands A_hundreds A_ones A_tens A_thousands B_hundreds B_ones B_tens B_thousands C_hundreds C_ones C_tens}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Top -layer 1 -spreadType center -spacing 1.33 -pin {G_thousands D_hundreds D_ones D_tens D_thousands E_hundreds E_ones E_tens E_thousands F_hundreds F_ones F_tens F_thousands G_hundreds G_ones G_tens A_hundreds A_ones A_tens A_thousands B_hundreds B_ones B_tens B_thousands C_hundreds C_ones C_tens C_thousands}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 0.2 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 0.2 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 1.33 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 1.33 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
zoomBox -57.95400 -11.27450 169.21450 105.52000
zoomBox -42.12650 3.58200 122.00300 87.96600
zoomBox -67.69350 -20.79650 199.56450 116.60900
zoomBox -57.06250 -5.17550 170.10650 111.61900
zoomBox -48.02650 8.51200 145.06750 107.78750
zoomBox -31.44950 29.46800 87.13500 90.43600
zoomBox -43.61550 9.15100 149.48050 108.42750
zoomBox -49.12750 -0.15200 178.04450 116.64400
zoomBox -42.89850 3.08500 150.19800 102.36200
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 5 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
zoomBox -77.49500 -25.84800 292.41750 164.33550
zoomBox -61.94650 -18.47400 252.47900 143.18200
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 4 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 3 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 3.2 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 3.33 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 3.5 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 3.61 -pin {true_false_display_sel_switch _clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s}
setPinAssignMode -pinEditInBatch false
zoomBox -103.49100 -58.24000 331.70050 165.50550
zoomBox -66.05300 -17.40650 248.37300 144.24950
zoomBox -51.53250 -1.15600 215.73000 136.25200
zoomBox -68.40700 -18.34250 246.01950 143.31400
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 2.33 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Bottom -layer 1 -spreadType center -spacing 2.33 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Bottom -layer 1 -spreadType center -spacing 3.33 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Bottom -layer 1 -spreadType center -spacing 2.5 -pin {{rand_led_onehot[0]} {rand_led_onehot[1]} {rand_led_onehot[2]} {rand_led_onehot[3]} {rand_led_onehot[4]} {rand_led_onehot[5]} {rand_led_onehot[6]} {rand_led_onehot[7]} {rand_led_onehot[8]} {rand_led_onehot[9]} {rand_led_onehot[10]} {rand_led_onehot[11]} {rand_led_onehot[12]} {rand_led_onehot[13]} {rand_led_onehot[14]} {rand_led_onehot[15]} {rand_led_onehot[16]} {rand_led_onehot[17]} {rand_led_onehot[18]} {rand_led_onehot[19]} {rand_led_onehot[20]} {rand_led_onehot[21]} {rand_led_onehot[22]} {rand_led_onehot[23]} {rand_led_onehot[24]} {rand_led_onehot[25]} {rand_led_onehot[26]} {rand_led_onehot[27]} {rand_led_onehot[28]} {rand_led_onehot[29]} {rand_led_onehot[30]} {rand_led_onehot[31]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 2.5 -pin {{rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Right -layer 1 -spreadType center -spacing 2.66 -pin {{rand_led_onehot[32]} {rand_led_onehot[33]} {rand_led_onehot[34]} {rand_led_onehot[35]} {rand_led_onehot[36]} {rand_led_onehot[37]} {rand_led_onehot[38]} {rand_led_onehot[39]} {rand_led_onehot[40]} {rand_led_onehot[41]} {rand_led_onehot[42]} {rand_led_onehot[43]} {rand_led_onehot[44]} {rand_led_onehot[45]} {rand_led_onehot[46]} {rand_led_onehot[47]} {rand_led_onehot[48]} {rand_led_onehot[49]} {rand_led_onehot[50]} {rand_led_onehot[51]} {rand_led_onehot[52]} {rand_led_onehot[53]} {rand_led_onehot[54]} {rand_led_onehot[55]} {rand_led_onehot[56]} {rand_led_onehot[57]} {rand_led_onehot[58]} {rand_led_onehot[59]} {rand_led_onehot[60]} {rand_led_onehot[61]} {rand_led_onehot[62]} {rand_led_onehot[63]}}
setPinAssignMode -pinEditInBatch false
zoomBox -30.54800 14.35200 196.62500 131.14850
zoomBox -15.42600 26.68750 177.67100 125.96450
zoomBox 47.43900 57.11200 133.11650 101.16150
zoomBox 54.99700 60.86000 127.82300 98.30200
zoomBox -85.73100 -10.69100 228.69550 150.96550
fit
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Top -layer 1 -spreadType center -spacing 2.5 -pin {A_hundreds A_ones A_tens A_thousands B_hundreds B_ones B_tens B_thousands C_hundreds C_ones C_tens C_thousands D_hundreds D_ones D_tens D_thousands E_hundreds E_ones E_tens E_thousands F_hundreds F_ones F_tens F_thousands G_hundreds G_ones G_tens G_thousands}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Top -layer 1 -spreadType center -spacing 2.8 -pin {A_hundreds A_ones A_tens A_thousands B_hundreds B_ones B_tens B_thousands C_hundreds C_ones C_tens C_thousands D_hundreds D_ones D_tens D_thousands E_hundreds E_ones E_tens E_thousands F_hundreds F_ones F_tens F_thousands G_hundreds G_ones G_tens G_thousands}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 0.2 -pin {_clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s true_false_display_sel_switch}
setPinAssignMode -pinEditInBatch false
undo
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 0.38 -pin {_clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s true_false_display_sel_switch}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 4 -pin {_clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s true_false_display_sel_switch}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 3.5 -pin {_clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s true_false_display_sel_switch}
setPinAssignMode -pinEditInBatch false
getPinAssignMode -pinEditInBatch -quiet
setPinAssignMode -pinEditInBatch true
editPin -pinWidth 0.06 -pinDepth 0.335 -fixOverlap 1 -unit MICRON -spreadDirection clockwise -side Left -layer 1 -spreadType center -spacing 3.61 -pin {_clicker _start_test clk_1kHz_ext clk_16MHz clk_mux_s {seed[0]} {seed[1]} {seed[2]} {seed[3]} {seed[4]} {seed[5]} {seed[6]} {seed[7]} {seed[8]} {seed[9]} {seed[10]} {seed[11]} {seed[12]} {seed[13]} {seed[14]} {seed[15]} seed_mux_s true_false_display_sel_switch}
setPinAssignMode -pinEditInBatch false
zoomBox -64.47000 -15.33150 162.69850 101.46300
zoomBox -48.30350 -3.87750 144.79050 95.39800
zoomBox -58.22100 -18.01600 168.94850 98.77900
zoomBox -52.40200 -7.52500 140.69250 91.75100
setSrouteMode -viaConnectToShape { noshape }
sroute -connect { corePin floatingStripe } -layerChangeRange { Metal1(1) Metal11(11) } -blockPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -floatingStripeTarget { blockring padring ring stripe ringpin blockpin followpin } -allowJogging 1 -crossoverViaLayerRange { Metal1(1) Metal11(11) } -allowLayerChange 1 -targetViaLayerRange { Metal1(1) Metal11(11) }
setSrouteMode -viaConnectToShape { noshape }
sroute -connect { corePin floatingStripe } -layerChangeRange { Metal1(1) Metal11(11) } -blockPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -floatingStripeTarget { blockring padring ring stripe ringpin blockpin followpin } -allowJogging 1 -crossoverViaLayerRange { Metal1(1) Metal11(11) } -allowLayerChange 1 -targetViaLayerRange { Metal1(1) Metal11(11) }
zoomBox -9.61450 4.89800 108.97100 65.86650
zoomBox 0.60050 7.83950 101.39800 59.66250
zoomBox 22.92900 14.17050 84.83200 45.99700
zoomBox -35.69150 -2.23550 128.44500 82.15200
zoomBox -51.99450 -6.64200 141.10750 92.63750
zoomBox -36.94600 -2.27050 127.19100 82.11750
setDrawView ameba
setDrawView ameba
setDrawView place
setDrawView fplan
setDrawView place
zoomBox -104.55400 -39.05000 162.71650 98.36200
zoomBox -80.18200 -23.09100 146.99850 93.70950
zoomBox -59.54750 -8.80850 133.55600 90.47200
zoomBox -42.26900 3.74950 121.86900 88.13800
zoomBox 16.92300 45.50550 78.82850 77.33300
zoomBox 41.35350 61.64100 61.20050 71.84500
zoomBox 47.63900 65.82600 56.44600 70.35400
zoomBox 50.24750 67.80800 53.56950 69.51600
zoomBox 44.86850 63.75500 59.21400 71.13050
zoomBox 33.35450 54.94950 71.39400 74.50700
zoomBox 10.18100 37.22500 95.91450 81.30350
zoomBox 2.82950 31.60250 103.69300 83.45950
zoomBox -5.81850 24.98800 112.84400 85.99600
zoomBox -86.35400 -10.88350 140.96700 105.98950
zoomBox -61.95450 -0.63150 131.26850 98.71050
zoomBox -39.47200 0.88500 124.76750 85.32550
zoomBox -54.49550 -9.55500 138.72750 89.78700
zoomBox -38.11300 -6.62750 126.12700 77.81350
zoomBox -54.20000 -10.77550 139.02400 88.56700
getDesignMode -user -bottomRoutingLayer
getDesignMode -user -topRoutingLayer
setNanoRouteMode -quiet -drouteFixAntenna 1
setNanoRouteMode -quiet -routeInsertAntennaDiode 0
setNanoRouteMode -quiet -routeWithTimingDriven 0
setNanoRouteMode -quiet -routeWithEco 0
setNanoRouteMode -quiet -routeWithLithoDriven 0
setNanoRouteMode -quiet -droutePostRouteLithoRepair 0
setNanoRouteMode -quiet -routeWithSiDriven 0
setNanoRouteMode -quiet -drouteAutoStop 0
setNanoRouteMode -quiet -routeSelectedNetOnly 0
getDesignMode -quiet -topRoutingLayer
getDesignMode -quiet -bottomRoutingLayer
setNanoRouteMode -quiet -drouteEndIteration 1
setNanoRouteMode -quiet -routeWithTimingDriven false
setNanoRouteMode -quiet -routeWithSiDriven false
routeDesign -globalDetail
zoomBox -73.10500 -25.33350 154.21750 91.54000
zoomBox -93.70550 -37.15350 173.73250 100.34450
zoomBox -73.05650 -17.27700 154.26550 99.59650
zoomBox -56.22300 -0.17650 137.00100 99.16600
zoomBox -42.40200 14.11500 121.83800 98.55600
zoomBox -12.14400 44.86900 88.72150 96.72700
zoomBox -4.92050 52.21100 80.81550 96.29050
zoomBox 11.00800 67.79700 63.66200 94.86800
zoomBox 23.50850 78.48150 50.99500 92.61300
zoomBox 25.55650 80.22900 48.92000 92.24100
zoomBox 12.14700 69.54350 64.80500 96.61650
zoomBox 7.90600 66.13500 69.85650 97.98550
zoomBox -17.84900 45.48450 100.82900 106.50050
fit
getFillerMode -quiet
addFiller -cell FILL1 FILL8 FILL64 FILL4 FILL32 FILL2 FILL16 -prefix FILLER
getMultiCpuUsage -localCpu
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell true -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report perimeter.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
zoomBox -62.98200 -42.01300 83.16850 88.82300
zoomBox -96.15650 -81.48800 106.12750 99.59950
zoomBox -13.13750 -9.16150 92.45700 85.36800
zoomBox -1.06850 3.33750 88.68700 83.68800
zoomBox 18.71700 32.71050 73.83900 82.05650
zoomBox 29.83450 51.06200 63.68700 81.36700
zoomBox 32.50150 55.43000 61.27600 81.18950
zoomBox 36.73150 62.10350 57.52200 80.71550
zoomBox 43.13500 71.38250 52.36050 79.64150
zoomBox 45.98150 75.41150 50.07600 79.07700
zoomBox 46.82650 76.62900 49.34150 78.88050
zoomBox 45.21850 74.25850 50.88850 79.33450
zoomBox 42.79700 70.40650 53.65950 80.13100
zoomBox 41.92850 68.98750 54.70850 80.42850
zoomBox 40.91600 67.31850 55.95150 80.77850
zoomBox 38.35050 63.04500 59.16100 81.67500
zoomBox 36.75900 60.32750 61.24200 82.24500
zoomBox 23.65450 37.61450 78.83350 87.01150
zoomBox -15.44000 -28.57850 130.86700 102.39750
zoomBox 19.16450 -8.69100 84.08200 49.42400
zoomBox 34.95500 1.42650 63.75950 27.21250
zoomBox 36.84400 2.67800 61.32800 24.59650
zoomBox 42.02100 6.05350 54.80300 17.49600
zoomBox 44.91400 7.94250 51.58600 13.91550
zoomBox 46.43550 9.81550 49.91900 12.93400
zoomBox 47.07700 10.59950 49.21650 12.51500
zoomBox 47.23000 10.78650 49.04900 12.41500
zoomBox 47.36150 10.93050 48.90750 12.31450
zoomBox 47.64700 11.24350 48.59650 12.09350
zoomBox 45.88250 9.20350 50.70750 13.52300
zoomBox 43.11100 5.83000 53.98650 15.56600
zoomBox 38.54900 0.19900 59.38500 18.85150
zoomBox 29.81150 -10.54350 69.72700 25.18950
zoomBox 18.32550 -24.58000 83.32150 33.60550
zoomBox -1.04000 -45.91050 104.79550 48.83500
zoomBox -10.58400 -54.00500 113.92850 57.46050
zoomBox -24.22850 -61.16850 122.25700 69.96750
fit
zoomBox 19.33800 31.84500 77.22600 83.66700
zoomBox 23.71850 38.74200 72.92350 82.79100
zoomBox 36.95550 62.37900 58.78900 81.92450
zoomBox 41.07500 69.62650 54.48400 81.63050
zoomBox 44.83750 75.62400 50.78800 80.95100
zoomBox 46.63850 78.20700 49.27900 80.57100
zoomBox 46.84650 78.51100 49.09100 80.52050
zoomBox 47.02350 78.76350 48.93200 80.47200
zoomBox 47.17450 78.97800 48.79700 80.43050
zoomBox 47.02300 78.76300 48.93200 80.47200
zoomBox 46.84450 78.51000 49.09100 80.52100
zoomBox 46.63500 78.21250 49.27800 80.57850
zoomBox 46.38950 77.86400 49.49900 80.64750
zoomBox 45.44100 76.39500 50.50500 80.92850
zoomBox 43.96750 74.22550 52.21400 81.60800
zoomBox 41.42100 69.23950 57.22000 83.38300
zoomBox 35.27750 55.86950 70.88500 87.74600
zoomBox 28.44600 40.72750 86.42800 92.63400
zoomBox 12.23500 4.87300 123.31200 104.31050
zoomBox -19.26600 -62.89500 193.52300 127.59650
zoomBox -45.69300 -85.72700 204.64750 138.38100
zoomBox -17.22200 -30.17150 136.51850 107.45900
zoomBox -8.24250 5.36150 86.17350 89.88400
fit
zoomBox -31.32350 -18.61400 249.35400 125.69100
zoomBox -60.95900 -33.53600 269.25000 136.23450
fit
zoomBox -0.31200 25.15400 100.48350 76.97600
zoomBox 33.26050 40.39200 85.87650 67.44350
zoomBox 51.47150 45.87750 83.78500 62.49100
zoomBox 60.06750 49.31150 79.91250 59.51450
zoomBox 66.12050 51.89150 76.48100 57.21800
zoomBox 69.22050 53.13600 74.62900 55.91650
fit
zoomBox -197.19350 -32.73250 172.71200 157.44750
zoomBox -121.85550 -13.75450 145.40150 123.65050
fit
setLayerPreference violation -isVisible 1
violationBrowser -all -no_display_false -displayByLayer
violationBrowserClose
win off
