
# This is the NC-SIM(R) probe command file
# used in the AMS-ADE integration.


#
# Database settings
#
if { [info exists ::env(AMS_RESULTS_DIR) ] } { set AMS_RESULTS_DIR $env(AMS_RESULTS_DIR)} else {set AMS_RESULTS_DIR "../psf"}
database -open ams_database -into ${AMS_RESULTS_DIR} -default

#
# Probe settings
#
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.A_hundreds}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.A_ones}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.A_tens}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.A_thousands}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.B_hundreds}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.B_ones}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.B_tens}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.B_thousands}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.C_hundreds}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.C_ones}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.C_tens}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.C_thousands}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.D_hundreds}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.D_ones}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.D_tens}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.D_thousands}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.E_hundreds}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.E_ones}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.E_tens}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.E_thousands}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.F_hundreds}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.F_ones}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.F_tens}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.F_thousands}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.G_hundreds}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.G_ones}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.G_tens}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.G_thousands}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[0]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[1]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[2]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[3]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[4]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[5]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[6]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[7]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[8]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[9]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[10]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[11]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[12]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[13]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[14]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[15]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[16]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[17]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[18]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[19]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[20]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[21]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[22]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[23]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[24]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[25]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[26]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[27]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[28]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[29]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[30]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[31]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[32]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[33]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[34]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[35]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[36]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[37]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[38]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[39]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[40]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[41]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[42]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[43]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[44]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[45]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[46]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[47]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[48]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[49]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[50]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[51]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[52]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[53]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[54]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[55]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[56]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[57]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[58]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[59]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[60]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[61]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[62]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.net8[63]}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb._clicker}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb._start_test}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.clk_1kHz_ext}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.clk_mux_s}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.seed}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.seed_mux_s}
probe -create -emptyok -database ams_database {digital_perimeter_system_tb.true_false_display_s}

