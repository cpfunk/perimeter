# ####################################################################

#  Created by Genus(TM) Synthesis Solution 25.10-p002_1 on Mon May 04 01:31:44 CDT 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design perimeter

set_clock_gating_check -setup 0.0 
