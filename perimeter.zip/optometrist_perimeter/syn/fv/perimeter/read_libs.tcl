add_search_path ../lib -library -both
read_library -liberty -both \
    /home/cpfunk/gpdk45/optometrist_perimeter/syn/../lib/basicCells.lib

