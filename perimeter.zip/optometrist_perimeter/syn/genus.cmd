# Cadence Genus(TM) Synthesis Solution, Version 25.10-p002_1, built Apr 17 2025 15:35:38

# Date: Sun May 03 02:17:53 2026
# Host: linuxvdi-f25-20.ece.iastate.edu (x86_64 w/Linux 5.14.0-570.19.1.el9_6.x86_64) (4cores*4cpus*1physical cpu*Intel(R) Xeon(R) Gold 6354 CPU @ 3.00GHz 39936KB)
# OS:   Red Hat Enterprise Linux 9.6 (Plow)

gui_show
set OUTPUT_DIR ../synthesis_outputs
set_db / .init_lib_search_path {../lib}
set_db / .library {basicCells.lib}
set_db / .library {basicCells.lib}
set_db / .library{basicCells.lib}
set_db / .init_lib_search_path {../lib}
set_db / .library {basicCells.lib}
set_db / .init_lib_search_path {../lib}
set OUTPUT_DIR ../synthesis_outputs
set_db / .init_lib_search_path {../lib}
set_db / .library {basicCells.lib}
quit
